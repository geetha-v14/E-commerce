const { body } =
  require("express-validator");

const registerValidation = [

  body("name")
    .trim()
    .notEmpty()
    .withMessage("Name is required"),

  body("email")
    .isEmail()
    .withMessage("Valid email required"),

  body("password")
    .isLength({ min: 6 })
    .withMessage(
      "Password must be minimum 6 characters"
    ),

];

const loginValidation = [

  body("email")
    .isEmail()
    .withMessage("Valid email required"),

  body("password")
    .notEmpty()
    .withMessage("Password required"),

];

module.exports = {
  registerValidation,
  loginValidation,
};